#Cameron Booker 2019

import socket

UDP_IP = "192.168.0.62"
UDP_PORT = 5005

sock = socket.socket(socket.AF_INET, #Internet
socket.SOCK_DGRAM) #UDP
sock.bind((UDP_IP, UDP_PORT))
datafold = 465783


while True:
	data, addr = sock.recvfrom(1024)
	datafnew = float(data)
	if datafnew == datafold:
		x = 1
#		print("same")
	else:
		print datafnew
	datafold = datafnew
