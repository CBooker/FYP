from guizero import App

app = App(title="Hello world")
app.display()
