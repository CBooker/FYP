#Cameron Booker - 01/03/18
#Import assets from guizero library, and other required libraries

from guizero import App, Box, Text, TextBox, PushButton, Slider, Picture, Combo, CheckBox, ButtonGroup, Waffle, Window
import time


app = App(title="Save the Doggos", width=800, height=600, layout="grid")     #Start of the app, where size of window and layout is declared




app.display()       #put the app on the screen
