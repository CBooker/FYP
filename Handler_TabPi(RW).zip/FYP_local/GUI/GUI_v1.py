#Cameron Booker - 01/03/18
#Import assets from guizero library, and other required libraries


#***IMPORTING LIBRARIES***


from guizero import App, Box, Text, TextBox, PushButton, Slider, Picture, Combo, CheckBox, ButtonGroup, Waffle, Window
import time
from bluetooth import *


#***BLUETOOTH SOCKETS, PORTS, UUID AND SERIAL PORT SETUP


server_sock=BluetoothSocket( RFCOMM )
server_sock.bind(("",PORT_ANY))
server_sock.listen(1)

port = server_sock.getsockname()[1]

uuid = "94f39d29-7d6d-437d-973b-fba39e49d4ee"

advertise_service( server_sock, "Handler_Tab",
                   service_id = uuid,
                   service_classes = [ uuid, SERIAL_PORT_CLASS ],
                   profiles = [ SERIAL_PORT_PROFILE ], 
#                   protocols = [ OBEX_UUID ] 
                    )
                   
print("Waiting for connection on RFCOMM channel")

client_sock, client_info = server_sock.accept()
print("Accepted connection from ", client_info)


#***FUNCTIONS AND COMMANDS***

def temprecv():
    datafold = -45.6784
    data = str(client_sock.recv(1024))
    if any(i in "Temp" for i in data):
        try:
            print("in try")
            while True:
                print("in while loop")
                print("data recv")
                if len(data) == 0: break
                datafnew = ""
                datafnew = data
#                datafnew = float(data)
                print("data = data")
#                if datafnew == datafold:
#                    temp_print.value=datafold
#                else:
#                    temp_print.value = datafnew
                datafold = datafnew
                return datafold
                break
#                print("", datafnew)    
            print("out of while")    
        except IOError:
            print("IOError")
            pass
    else:
        print("temp didn't work fam")


def HRrecv():
    while True:
        data = str(client_sock.recv(1024))
        if len(data) == 0:  break
#        HR_print.value = data
        return data
        break

def UpdateTemp():
    temp_print.value=temprecv()
    temp_print.after(50, UpdateTemp)
    

def UpdateHR(): 
    HR_print.value=HRrecv()
    HR_print.after(50, UpdateHR)

def Plus50ml():
    Water_print.value=int(Water_print.value)+50

def Plus100ml():
    Water_print.value=int(Water_print.value)+100


app = App(title="Handler_Tab_v1", width=800, height=600, layout="grid")     #Start of the app, where size of window and layout is declared

temp_print = Text(app, text= "temperature here", grid=[0,0], align="left")
temp_CentiSymbol = Text(app, text= "*C              ", grid=[1,0], align="left")

#temp_button = PushButton(app, command=UpdateTemp, text="Temperature", grid=[1,1], align="left")

HR_print = Text(app, text="HR here", grid=[0,2], align="left")
HR_bpm = Text(app, text="bpm            ", grid=[1,2], align="left")
#HR_button = PushButton(app, command=UpdateHR, text="Heart Rate", grid = [5,1], align="left")

Water_print= Text(app, text="0", grid=[0,4], align="left")
Water_50ml = PushButton(app, command=Plus50ml, text="+50ml", grid=[0,5])
Water_100ml = PushButton(app, command=Plus100ml, text="+100ml", grid=[1,5])



temp_print.after(50, UpdateTemp)
HR_print.after(50, UpdateHR)

app.display()




#except IOError:
#    pass

#print("disconnected")

#client_sock.close()
#server_sock.close()
#print("all done")





#app.display()       #put the app on the screen



print("Disconnected!")
client_sock.close()
server_sock.close()
print("Sockets Closed, Connection Broken. Check client side!")
