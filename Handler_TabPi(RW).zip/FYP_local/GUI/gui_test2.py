from guizero import App, Combo, Text, TextBox, PushButton, Slider, CheckBox
from random import randint

def rando():
    r = randint(1,3)
    if r == 1:
        rstr = "Frozen"
    elif r ==2:
        rstr = "Lion King"
    elif r == 3:
        rstr = "Blackhawk Down"
    else:
        rstr = r
    random_text.value = rstr

app = App(title="Second GUI", width=300, height=200, layout="grid")

film_choice = Combo(app, options=["Frozen", "Lion King", "Blackhawk Down"], grid=[1,0], align="left")            
film_question = Text(app, text="which film?", grid=[0,0], align="left")

vip_seat = CheckBox(app, text="VIP Seat", grid=[1,1], align="left")
seat_type = Text(app, text="Seat Type:", grid=[0,1], align="left")

random_text = Text(app, text="Random movie here", grid=[0,2], align="left")
random_button = PushButton(app, command=rando, text="Choose for me!", grid=[1,2], align="left")

app.display()
