#Cameron Booker - 31/01/18

import os
import glob
import time
 
os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')					#setting "1-wire sensor"
 
base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]
device_file = device_folder + '/w1_slave'			#establishing default directory
 
def read_temp_raw():
    f = open(device_file, 'r')
    lines = f.readlines()
    f.close()
    return lines									#accessing the file to take the immediate data from the sensor
 
def read_temp():
    lines = read_temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = read_temp_raw()
    equals_pos = lines[1].find('t=')
    if equals_pos != -1:
        temp_string = lines[1][equals_pos+2:]
        temp_c = float(temp_string) / 1000.0
        temp_f = temp_c * 9.0 / 5.0 + 32.0			#taking the raw data and manipulating it to get an output in celcius and fahrenheit.
        return temp_c							#only need temp in c

x = 1	
while True:

	if x == 1:
		intemp = input("input a temp")
		try:
			temp = float(intemp)
			tempdiff = read_temp() - temp
			print("The temperature difference is: ", tempdiff)
		except ValueError:
			print("Input number only.")
		else:
			temp = float(intemp)
			tempdiff = read_temp() - temp
			print("The temperature difference is: ", tempdiff)
#		print(read_temp())							#print temperature to terminal
		time.sleep(0.01)							#should spam out some value
		x +=1
	else:
		temp = float(intemp)
		tempdiff = read_temp() - temp
		print("The temperature difference is: ", tempdiff)
