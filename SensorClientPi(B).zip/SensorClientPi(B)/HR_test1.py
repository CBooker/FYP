import time

# Import SPI library (for hardware SPI) and MCP3008 library.
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008

SPI_PORT   = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))

tim = 0.1
beats = 0
P = False
T = False
f = open("90bpm.txt","w+")
while True:
    thump = mcp.read_adc(0)
#    print(thump)
    if thump < 400:
        #print("trough")
        T = True
    if thump > 700:
        #print("peak")
        P = True
    if P == True & T == True:
#        print("beat!")
        T = False
        P = False
        beats = beats+1
    # Pause for half a second.
    time.sleep(0.1)
    thump = str(thump)
    f.write(thump)
    f.write('\n')
    tim=tim+0.1
    bpm=beats/(tim/60)
#    print(tim)
    print("bpm=:", bpm)
