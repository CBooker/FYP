from guizero import App, Text, TextBox, PushButton, Slider, Picture
#import assets from guizero lib
import time

def say_my_name():
    welcome_message.value = my_name.value

def change_text_size(slider_value):
    welcome_message.size = slider_value

app = App(title = "hello world!")       #start app event loop (works like While True)

welcome_message = Text(app, text = "Weclome to my app", size=32, font = "Times New Roman", color="black")

my_name = TextBox(app)

update_text = PushButton(app,command=say_my_name, text="Display my name")

text_size = Slider(app, command=change_text_size, start = 10, end = 80)

my_baby = Picture(app, image="Norton V4 SS.jpg")

app.display()                           #app written, display it
