from guizero import App, PushButton, Slider, Text

#def smaller(tsize):
#    tsize=tsize-1
#    print(tsize)
#    return tsize

#def larger(tsize):
#    tsize=tsize+1    
#    print(tsize)
#    return tsize



app = App(title="Box Size Test", layout = "grid")

tsize = 12

text_here = Text(app, text="Will I do a fuckin thing?", size= tsize, grid=[0,0], align = "left")

print(tsize)

def smaller():
    tsize=tsize-1
    print(tsize)

def larger():
    tsize=tsize+1    
    print(tsize)


smaller = PushButton(app, command=smaller, text="smaller",grid = [1,0], align = "left")

larger = PushButton(app, command=larger, text="larger",grid = [1,1], align = "left")


app.display()
