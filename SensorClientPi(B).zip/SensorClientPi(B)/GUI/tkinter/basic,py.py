from tkinter import *
from PIL import Image, ImageTk

class Window(Frame):

#MASTER

    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.master=master
        self.init_window()
        
#Creating first window

    def init_window(self):

        #Change title of master widget
        self.master.title("GUI")

        #allow widget to take up all of window
        self.pack(fill=BOTH, expand=1)

        #creating a menu instance, and creating it
        menu = Menu(self.master)
        self.master.config(menu=menu)
        file = Menu(menu)

        #adding a command to the menu to exit
        file.add_command(label="exit", command=self.client_exit)

        #adding an edit to the file, and giving it some options to show text and an image
        edit = Menu(menu)
        edit.add_command(label="Show Image", command=self.showImg)
        edit.add_command(label="Show Text", command=self.showText)
        menu.add_cascade(label="Edit", menu=edit)
        

        #creating a button
        #quitButton = Button(self, text="quit", command=self.client_exit)

        #putting button into window
        #quitButton.place(x=0, y=0)

#Creating ShowImg function

    def showImg(self):
        load = Image.open("Norton V4 SS.jpg")
        render = ImageTk.PhotoImage(load)
        img = Label(self, image=render)
        img.image = render
        img.place(x=0,y=0)

#Creating showText function

    def showText(self):
        text = Label(self, text="Hey there good lookin'!")
        text.pack()


#Creating exit function

    def client_exit(self):
        exit()


root = Tk()

#size of the window
root.geometry("400x300")



app= Window(root)
root.mainloop()
