#Cameron Booker 2019

from bluetooth import *
import sys
import os
import glob
import time

os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')				    	#setting "1-wire sensor"
 
base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]
device_file = device_folder + '/w1_slave'			#establishing default directory
 
def read_temp_raw():
    f = open(device_file, 'r')
    lines = f.readlines()
    f.close()
    return lines									#accessing the file to take the immediate data from the sensor
 
def read_temp():
    lines = read_temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = read_temp_raw()
    equals_pos = lines[1].find('t=')
    if equals_pos != -1:
        temp_string = lines[1][equals_pos+2:]
        temp_c = float(temp_string) / 1000.0
        return temp_c							    #returning celcius value


if sys.version < '3':
    input = raw_input

addr = "B8:27:EB:20:D4:65"

if len(sys.argv) < 2:
    print("Searching all nearby bluetooth devices for the Handler_Tab")
else:
    addr = sys.argv[1]
    print("Searching for Handler_Tab on %s" % addr)

# search for the SampleServer service
uuid = "94f39d29-7d6d-437d-973b-fba39e49d4ee"
service_matches = find_service( uuid = uuid, address = addr )

if len(service_matches) == 0:
    print("couldn't find the Handler_Tab, try again!")

first_match = service_matches[0]
port = first_match["port"]
name = first_match["name"]
host = first_match["host"]

print("connecting to \"%s\" on %s" % (name, host))

# Create the client socket
sock=BluetoothSocket( RFCOMM )
sock.connect((host, port))

print("Connected. Standby for data")

x = 1

while True:	

    if x == 1:

#        intemp = input("input a temp")
        try:
#            temp = float(intemp)
            temp = 0
            tempdiff = read_temp() - temp
            print("The temperature difference is: ", tempdiff)

        except ValueError:
            print("Input number only.")

        else:
#            temp = float(intemp)
            temp = 0
            tempdiff = read_temp() - temp
            print("The temperature difference is: ", tempdiff)
#		print(read_temp())							#print temperature to terminal
        time.sleep(0.01)							#should spam out some value
        x +=1

    else:
#        temp = float(intemp)
        temp = 0
        tempdiff = read_temp() - temp
        print("The temperature difference is: ", tempdiff)


    tempdiff = str(tempdiff)    
    data = tempdiff

    if len(data) == 0: break
    sock.send(data)

sock.close()
