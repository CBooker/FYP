import time
import serial

x = 1

while x == 1:

	ser = serial.Serial('/dev/ttyACM0', 9600)
	print("connection")

	out = ser.read(20)
#	read = str(out)
	print("out read")

	if out in ["TILT: X AXIS"]:
		print("x axis tilting :)")
	elif out in ["TILT: Y AXIS"]:
		print("y axis tilting :(")
	else:
		print("all ok") 

	print("end of while")
	time.sleep(1)




