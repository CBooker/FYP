#Cameron Booker testing 23/11/18
#updated 30/01/19

import time
import serial


#Establish connection on the port

ser = serial.Serial('/dev/ttyACM0', 9600)


x = 1
while x==1:
	out = ser.read(4)
#	if out in ("TILT: X AXIS"):
#		print ("tilted x axis")
#	if out in ("all okall ok"):
#		print("no tilt")
#	elif out in ("TILT: Y AXIS"):
#		print("tilted y axis")
#	else:
#		if out >= 20:
#			print("X axis exceeded")
#		else:
#			print(out)
	if any(i in "x" for i in out):
		out = [int(s) for s in out.split() if s.isdigit()]
		print("x axis", out)
	elif any(i in "y" for i in out):
		out = [int(s) for s in out.split() if s.isdigit()]
		print("y axis") 
#	if out in ("x"):
#		print("x axis")
#	elif out in ("y"):
#		print("y axis")
	time.sleep(0.5)
#	print(out)
