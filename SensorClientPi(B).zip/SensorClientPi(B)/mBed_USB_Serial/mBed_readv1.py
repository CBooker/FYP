#Cameron Booker testing 23/11/18
#updated 30/01/19

import time
import serial


#Establish connection on the port

ser = serial.Serial('/dev/ttyACM0', 9600)


x = 1
while x==1:
    out = ser.read(4)
    print(out)
