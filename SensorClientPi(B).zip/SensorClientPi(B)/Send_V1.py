#Cameron Booker 2019

#-=-=-=-=-=LIBRARY IMPORTS=-=-=-=-=-#

from bluetooth import *
import sys
import os
import glob
import time
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008


#-=-=-=-=-=SETUP FOR TEMPERATURE SENSOR=-=-=-=-=-#

os.system('modprobe w1-gpio')
os.system('modprobe w1-therm')				    	#setting "1-wire sensor"
 
base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]
device_file = device_folder + '/w1_slave'			#establishing default directory
 
def read_temp_raw():
    f = open(device_file, 'r')
    lines = f.readlines()
    f.close()
    return lines									#accessing the file to take the immediate data from the sensor
 
def read_temp():
    lines = read_temp_raw()
    while lines[0].strip()[-3:] != 'YES':
        time.sleep(0.2)
        lines = read_temp_raw()
    equals_pos = lines[1].find('t=')
    if equals_pos != -1:
        temp_string = lines[1][equals_pos+2:]
        temp_c = float(temp_string) / 1000.0
        return temp_c							    #returning celcius value





#-=-=-=-=-=SETUP FOR HEARTBEAT SENSOR=-=-=-=-=-#

SPI_PORT   = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))        #hardware SPI setup





#-=-=-=-=-=SETUP FOR BLUETOOTH TRANSMISSION=-=-=-=-=-#


if sys.version < '3':
    input = raw_input

addr = "B8:27:EB:20:D4:65"

if len(sys.argv) < 2:
    print("Searching all nearby bluetooth devices for the Handler_Tab")
else:
    addr = sys.argv[1]
    print("Searching for Handler_Tab on %s" % addr)

# search for the SampleServer service
uuid = "94f39d29-7d6d-437d-973b-fba39e49d4ee"
service_matches = find_service( uuid = uuid, address = addr )

if len(service_matches) == 0:
    print("couldn't find the Handler_Tab, try again!")

first_match = service_matches[0]
port = first_match["port"]
name = first_match["name"]
host = first_match["host"]

print("connecting to \"%s\" on %s" % (name, host))

# Create the client socket
sock=BluetoothSocket( RFCOMM )
sock.connect((host, port))

print("Connected. Standby for data")






#---Quick Declarations before main loop---#


x = 1
tim = 0.1
beats = 0
P = False
T = False
f = open("90bpm.txt","w+")



#-=-=-=-=-=ENTERING MAIN LOOP=-=-=-=-=-#



while True:	


#---Temperature code---#


    if x == 1:

#        intemp = input("input a temp")
        try:
#            temp = float(intemp)
            temp = 0
            tempdiff = read_temp() - temp
            print("Temp: ", tempdiff)

        except ValueError:
            print("Input number only.")

        else:
#            temp = float(intemp)
            temp = 0
            tempdiff = read_temp() - temp
            print("Temp: ", tempdiff)
#		print(read_temp())							#print temperature to terminal
        time.sleep(0.01)							#should spam out some value
        x +=1

    else:
#        temp = float(intemp)
        temp = 0
        tempdiff = read_temp() - temp
        print("Temp: ", tempdiff)


#---HR Code---#


    thump = mcp.read_adc(0)
#    print(thump)
    if thump < 400:
        #print("trough")
        T = True
    if thump > 750:
        #print("peak")
        P = True
    if P == True & T == True:
#        print("beat!")
        T = False
        P = False
        beats = beats+1
    # Pause for half a second.
    time.sleep(0.1)
    thump = str(thump)
    f.write(thump)
    f.write('\n')
    tim=tim+0.1
    bpm=beats/(tim/60)
#        print(tim)
    print("bpm=:", bpm)



#---Data Send---#


    tempdiff = str(tempdiff)
    tempdiff = str("Temp:" + tempdiff)
    bpm = str(bpm)
    bpm = str("HR:" + bpm)
        

    if len(tempdiff) == 0: break
    if len(bpm) == 0: break
    sock.send(tempdiff)
    sock.send(bpm)

sock.close()
