#Cameron Booker 2019

import socket

UDP_IP = "192.168.0.62"
UDP_PORT = 5005
Message = "HW!"


sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.sendto(Message, (UDP_IP, UDP_PORT))

